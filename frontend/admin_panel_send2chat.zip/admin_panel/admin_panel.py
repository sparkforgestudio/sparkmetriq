# backend/api/routes/admin_auth.py
from fastapi import APIRouter, HTTPException, Depends, Response
from pydantic import BaseModel
from core.auths import create_access_token, verify_password
from services.databases import db
from datetime import timedelta

router = APIRouter()

class AdminLoginRequest(BaseModel):
    email: str
    password: str

@router.post("/login")
async def login_admin(data: AdminLoginRequest, response: Response):
    admin = await db["users"].find_one({"email": data.email})
    if not admin or not verify_password(data.password, admin["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")

    access_token = create_access_token({"sub": admin["email"], "role": admin["role"]}, expires_delta=timedelta(hours=12))
    response.set_cookie(key="access_token", value=access_token, httponly=True, samesite="lax")
    return {"message": "Login successful"}
